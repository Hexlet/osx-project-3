//
//  main.m
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
