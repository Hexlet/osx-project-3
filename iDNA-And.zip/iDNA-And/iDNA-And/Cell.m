//
//  Cell.m
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//

#import "Cell.h"

@implementation Cell



-(id)initWithCapacity:(NSUInteger)dnaLength {
    // Вызываем init метод родителя;
    NSMutableArray *alphabet=[NSMutableArray arrayWithObjects:@"A", @"T", @"G", @"C", nil];
    self = [super init];
    // Инициализируем массив;
    DNA = [NSMutableArray arrayWithCapacity:dnaLength];
    if (self) {
        _dnaLength = dnaLength;
        for (int i = 0; i < dnaLength; i++) {
            
            int newDNA = arc4random_uniform((int)[alphabet count]);
            
            // Заполнение ячеек ДНК случайными значениями;
            [DNA addObject: (NSString *) [alphabet objectAtIndex: newDNA]];
        }
    }
    return self;
}

-(id)initFromString:(NSString *)sourceString {
    // Вызываем init метод родителя;
    NSMutableArray *alphabet=[NSMutableArray arrayWithObjects:@"A", @"T", @"G", @"C", nil];
    self = [super init];
    // Инициализируем массив;
    DNA = [NSMutableArray arrayWithCapacity:[sourceString length]];
    if (self) {
        _dnaLength = [sourceString length];
        for (int i = 0; i < _dnaLength; i++) {
            
            int newDNA = arc4random_uniform((int)[alphabet count]);
            switch ([sourceString characterAtIndex:i]) {
                case 'A':
                    [DNA addObject: (NSString *) [alphabet objectAtIndex: 0]];
                    break;
                case 'T':
                    [DNA addObject: (NSString *) [alphabet objectAtIndex: 1]];
                    break;
                case 'G':
                    [DNA addObject: (NSString *) [alphabet objectAtIndex: 2]];
                    break;
                case 'C':
                    [DNA addObject: (NSString *) [alphabet objectAtIndex: 3]];
                    break;
                default:
                    // Заполнение ячеек ДНК случайными значениями;
                    [DNA addObject: (NSString *) [alphabet objectAtIndex: newDNA]];
                    break;
            }
            
        }
    }
    return self;
}

+(BOOL)isValidDNAString:(NSString *)string{
    
    NSCharacterSet *alphabet = [NSCharacterSet characterSetWithCharactersInString: @"ACGT"];
    
    for (NSUInteger i=0; i < [string length]; i++)
        
        if ( ![alphabet characterIsMember:[string characterAtIndex:i]] )
            return NO;
    
    
    return YES;
}

-(NSUInteger) hammingDistance:(Cell *) anotherDNA {
    // Считаем количество позиций, где значения не совпадают;
    int dist = 0; //Count
    if ([self->DNA count] == [anotherDNA->DNA count]) {
        
        for (int i = 0; i < [self->DNA count]; i++) {
            if ([self->DNA objectAtIndex:i] != [anotherDNA->DNA objectAtIndex:i])
                dist++;
        }
        return dist;
    }
       [NSException raise:@"Length error" format: @"DNA should be with equal lengths"];
    return [self->DNA count] + [anotherDNA->DNA count];
}

-(void) mutateDNA:(NSUInteger) percent {
    
    if (percent > 100) {
        [NSException raise: @"Persent error" format: @"Percent can be >=0 and <=100"];
        percent = 100;
    }
    NSMutableArray *alphabet=[NSMutableArray arrayWithObjects:@"A", @"T", @"G", @"C", nil];
    
    NSMutableArray *buf; // Контролирует замену значения на НОВОЕ;
    
    /*
     100 = [self->DNA count]
     Идея: создаем целочисленный массив из 100 перемешанных
     (различных) индексов от 0 до 99 myIntegers.
     Чтобы теперь мутировать N = mutator произвольных ячеек,
     достаточно обратиться к первым N
     элементам массива myIntegers.
     */
    
    // Массив, контролирующий выбор строго разных ячеек;
    NSMutableArray *myIntegers = [NSMutableArray array];
    
    // Заполняем его различными индексами
    for (NSUInteger i = 0; i < [self->DNA count]; i++)
        [myIntegers addObject:[NSNumber numberWithInteger:i]];
    
    // Перемешиваем массив
    for (NSUInteger i = 0; i < [self->DNA count]; ++i) {
        // Select a random element between i and end of array to swap with.
        NSUInteger nElements = [self->DNA count] - i;
        NSUInteger n = arc4random() % (nElements) + i;
        [myIntegers exchangeObjectAtIndex:i withObjectAtIndex:n];
    }
    
    
    for (int i = 0; i < (int)(percent * [self->DNA count]/100); i++) {
        
        
        int newDNA;
        
        newDNA = arc4random_uniform((int)[alphabet count] - 1);
        buf = [NSMutableArray arrayWithObjects:@"A", @"T", @"G", @"C", nil];
        // Делаем это, чтобы заменить текущую ячейку на случайный элемент, не равный данному;
        [buf removeObjectIdenticalTo:(NSString *) [self->DNA objectAtIndex: [[myIntegers objectAtIndex:i] intValue]]];
        // Замена значения случайно выбранной ячейки;
        
        [self->DNA replaceObjectAtIndex: [[myIntegers objectAtIndex: i] intValue] withObject:[buf objectAtIndex: newDNA]];
        
    }
}


-(NSString *) dnaAtIndex:(NSUInteger) index{
    return [self->DNA objectAtIndex:index];
}

-(NSString *) printable{
    
    NSString *str = [[NSString alloc] init];
    for (int i=0; i < (int)[self->DNA count]; i++){
        
        str = [str stringByAppendingString:[self->DNA objectAtIndex:i]];
    }
    return str;
}

-(Cell *) crossCellOne:(Cell *)cell{
    Cell * crossedCell = [[Cell alloc] initWithCapacity: [cell dnaLength]];
    
    for (int i = 0; i < [cell dnaLength]/2; i++) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[cell dnaAtIndex:i]];
    }
    
    for (int i = [cell dnaLength]/2; i < [cell dnaLength]; i++) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[self dnaAtIndex:i]];
    }
    
    return crossedCell;
}

-(Cell *) crossCellTwo:(Cell *)cell{
    Cell * crossedCell = [[Cell alloc] initWithCapacity: [cell dnaLength]];
    
    for (int i = 0; i < [cell dnaLength]; i+=2) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[cell dnaAtIndex:i]];
    }
    
    for (int i = 1; i < [cell dnaLength]; i+=2) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[self dnaAtIndex:i]];
    }
    
    return crossedCell;
}

-(Cell *) crossCellThree:(Cell *)cell{
    Cell * crossedCell = [[Cell alloc] initWithCapacity: [cell dnaLength]];
    
    for (int i = 0; i < (int)[cell dnaLength]*0.2; i++) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[cell dnaAtIndex:i]];
    }
    
    for (int i = (int)[cell dnaLength]*0.2; i < (int)[cell dnaLength]*0.8; i++) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[self dnaAtIndex:i]];
    }
    for (int i = (int)[cell dnaLength]*0.8; i < [cell dnaLength]; i++) {
        [crossedCell->DNA replaceObjectAtIndex:i  withObject:[cell dnaAtIndex:i]];
    }
    return crossedCell;
}

-(Cell *) crossCell:(Cell *) cell{
    Cell * crossedCell = [[Cell alloc] initWithCapacity: [cell dnaLength]];
    int number;
    number = arc4random_uniform(3);
    switch (number) {
        case 0:
            crossedCell = [self crossCellOne:cell];
            break;
        case 1:
            crossedCell = [self crossCellTwo:cell];
            break;
        case 2:
            crossedCell = [self crossCellThree:cell];
            break;
        default:
            break;
    }
    if (_dnaLength != [cell dnaLength]) [NSException raise:@"Length error" format:@"DNA should be with equal lengths"];
    return crossedCell;
}
@end