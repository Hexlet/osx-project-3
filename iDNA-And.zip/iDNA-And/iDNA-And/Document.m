//
//  Document.m
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//
//  Включение и выключение элементов интерфейса производится привязкой их свойства isEnabled к свойству данного объекта isWork.
//  Большая часть кода с KVC/KVO была взята из работы Анатолия Яшкина, за что ему искренняя благодарность :)

#import "Document.h"
#import "Population.h"

@implementation Document

- (id)init
{
    if (self = [super init]) {
/*--------------------------------------------------------------------------------------------------------*/        
        //Наблюдаем за некоторыми переменными;
        [self addObserver:self forKeyPath:@"dnaLength" options:NSKeyValueObservingOptionOld context:@"dnaLengthChanged"];
        [self addObserver:self forKeyPath:@"populationSize" options:NSKeyValueObservingOptionOld context:@"populationSizeChanged"];
        [self addObserver:self forKeyPath:@"mutationRate" options:NSKeyValueObservingOptionOld context:@"mutationRateChanged"];
        [self addObserver: self forKeyPath: @"minHammingDistance" options: 0 context: @"minHammingDistanceChanged"];
/*--------------------------------------------------------------------------------------------------------*/        
        //Инициализируем переменные;
        Cell * goal = [[Cell alloc] initWithCapacity: dnaLength];
        [self setValue: [NSNumber numberWithLong:80]        forKey: @"populationSize"];
        [self setValue: [NSNumber numberWithLong:30]        forKey: @"dnaLength"];
        [self setValue: [NSNumber numberWithLong:7]         forKey: @"mutationRate"];
        [self setValue: [NSNumber numberWithLong:0]         forKey: @"bestMatch"];
        [self setValue: [NSNumber numberWithLong:0]         forKey: @"generation"];
        [self setValue: [NSNumber numberWithLong:dnaLength] forKey: @"minHammingDistance"];
        [self setValue: [goal printable]                    forKey: @"goalDNA"];
        [self setValue: [NSNumber numberWithBool: YES]      forKey: @"firstStart"];
/*--------------------------------------------------------------------------------------------------------*/           
        
        
    }
    return self;
}
// Как учил нас Рахим, удаляемся из наблюдателей, перезаписывая метод dealloc;
-(void)dealloc{
    [self removeObserver: self  forKeyPath: @"dnaLength"];
    [self removeObserver: self  forKeyPath: @"mutationRate"];
    [self removeObserver: self  forKeyPath: @"populationSize"];
    [self removeObserver: self  forKeyPath: @"minHammingDistance"];
    
}
// Вот вспомогательный метод для KVO;
-(void)changeKeyPath: (NSString *) keyPath ofObject: (id) obj toValue: (id) newValue{
    [obj setValue: newValue forKey: keyPath];
}

-(void)observeValueForKeyPath:(NSString *) keyPath ofObject:(id) object change:(NSDictionary *) change context:(void *) context{
    
    
    id oldValue = [change objectForKey: NSKeyValueChangeOldKey];
    NSUndoManager *undo = [self undoManager];
    
 
    if (context == @"dnaLengthChanged") {
/*--------------------------------------------------------------------------------------------------------*/        
        
        [[undo prepareWithInvocationTarget: self] changeKeyPath: keyPath ofObject: object toValue: oldValue];
        [undo setActionName: @"Edit DNA length"];
        
/*--------------------------------------------------------------------------------------------------------*/
        // При изменениие длины ДНК, перегененрируем goalDNA и весь процесс начинаем заново;
        Cell * goal = [[Cell alloc] initWithCapacity: dnaLength];
        [self setValue: [goal printable]                     forKey: @"goalDNA"];
        [self setValue: [NSNumber numberWithBool: YES]       forKey: @"firstStart"];
        [self setValue: [NSNumber numberWithLong: 0]         forKey: @"bestMatch"];
        [self setValue: [NSNumber numberWithLong: dnaLength] forKey: @"minHammingDistance"];
        [self setValue: [NSNumber numberWithLong: 0]         forKey: @"generation"];
        [self setValue: [NSNumber numberWithLong: dnaLength]      forKeyPath: @"population.dnaLength"];
        [self setValue: [NSNumber numberWithLong: populationSize] forKeyPath: @"population.populationSize"];
        [self setValue: [NSNumber numberWithLong: mutationRate]   forKeyPath: @"population.mutationRate"];
    }
/*--------------------------------------------------------------------------------------------------------*/    
    // При изменении размера популяции весь процесс начинается сначала, но goalDNA НЕ перегенерируется;
    else if (context == @"populationSizeChanged") {
/*--------------------------------------------------------------------------------------------------------*/        
        [[undo prepareWithInvocationTarget:self] changeKeyPath:keyPath ofObject:object toValue:oldValue];
        [undo setActionName:@"Edit population size"];
/*--------------------------------------------------------------------------------------------------------*/        
        [self setValue:[NSNumber numberWithBool: YES]       forKey: @"firstStart"];
        [self setValue:[NSNumber numberWithLong: 0]         forKey: @"bestMatch"];
        [self setValue:[NSNumber numberWithLong: dnaLength] forKey: @"minHammingDistance"];
        [self setValue:[NSNumber numberWithLong: 0]         forKey: @"generation"];
        [self setValue: [NSNumber numberWithLong: dnaLength]      forKeyPath: @"population.dnaLength"];
        [self setValue: [NSNumber numberWithLong: populationSize] forKeyPath: @"population.populationSize"];
        [self setValue: [NSNumber numberWithLong: mutationRate]   forKeyPath: @"population.mutationRate"];
/*--------------------------------------------------------------------------------------------------------*/        
    }
    else if (context == @"mutationRateChanged"){
        [[undo prepareWithInvocationTarget:self] changeKeyPath:keyPath ofObject:object toValue:oldValue];
        [undo setActionName:@"Edit mutation rate"];
        [self setValue: [NSNumber numberWithLong: dnaLength]      forKeyPath: @"population.dnaLength"];
        [self setValue: [NSNumber numberWithLong: populationSize] forKeyPath: @"population.populationSize"];
        [self setValue: [NSNumber numberWithLong: mutationRate]   forKeyPath: @"population.mutationRate"];
    }
/*--------------------------------------------------------------------------------------------------------*/    
    else if (context == @"minHammingDistanceChanged"){
        if (dnaLength != 0) {
            NSUInteger tmpMatch = 100 - (100 * minHammingDistance/dnaLength); // Так вычисляется bestMatch в процентах;
            if (bestMatch < tmpMatch) {
                [self setValue:[NSNumber numberWithLong: tmpMatch] forKey: @"bestMatch"]; //Возможно оно изменилось;
            }
        }
/*--------------------------------------------------------------------------------------------------------*/        
        
    }
}

- (NSString *)windowNibName
{
    // Override returning the nib file name of the document
    // If you need to use a subclass of NSWindowController or if your document supports multiple NSWindowControllers, you should remove this method and override -makeWindowControllers instead.
    return @"Document";
}

- (void)windowControllerDidLoadNib:(NSWindowController *)aController
{
    [super windowControllerDidLoadNib:aController];
    // Add any code here that needs to be executed once the windowController has loaded the document's window.
    
    
    //Инициализируем значение переменной inWork в этом методе, потому что нам нужно, чтобы все элементы формы успели создаться;
    [self setValue:[NSNumber numberWithBool:NO] forKey:@"inWork"];
    
    
    //Заполняем текстовое поле значением переменной goalDNA;
    Cell * goal = [[Cell alloc] initWithCapacity: 30];
    [_fieldGoalDNA setStringValue: [goal printable]];
}

+ (BOOL)autosavesInPlace
{
    return YES;
}
// Следующие два метода я не трогал;
/*--------------------------------------------------------------------------------------------------------*/   
- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError
{
    
    // Останавливаем работу;
    [[_fieldGoalDNA window] endEditingFor:nil];
   

    return [NSKeyedArchiver archivedDataWithRootObject: population];
}

- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError
{
    Population * newPopulation = nil;
    @try {
        newPopulation = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    }
    @catch (NSException *exception) {
        if (outError){
            NSDictionary *dict = [NSDictionary dictionaryWithObject:@"The file is invalid" forKey:NSLocalizedFailureReasonErrorKey];
            *outError = [NSError errorWithDomain:NSOSStatusErrorDomain code:unimpErr userInfo:dict];
            return NO;
        }
    }
    // Восстанавливаем наши значения из newPopulation;
    population = newPopulation;
    [self setValue: [NSNumber numberWithLong:[population populationSize]]    forKey: @"populationSize"];
    [self setValue: [NSNumber numberWithLong:[population dnaLength]]         forKey: @"dnaLength"];
    [self setValue: [NSNumber numberWithLong:[population mutationRate]]      forKey: @"mutationRate"];
    [self setValue: [NSNumber numberWithLong:[population bestMatch]]         forKey: @"bestMatch"];
    [self setValue: [NSNumber numberWithLong:[population generation]]        forKey: @"generation"];
    [self setValue: [NSNumber numberWithLong:[[[population population] objectAtIndex: 0] hammingDistance:[population goalCell] ]]                                                         forKey: @"minHammingDistance"];
    [self setValue: [[population goalCell] printable]                        forKey: @"goalDNA"];
    [self setValue: [NSNumber numberWithBool: YES]                           forKey: @"firstStart"];
    [self setValue:[NSNumber numberWithBool:YES]                             forKey:@"inWork"];
    
    return YES;
}
/*--------------------------------------------------------------------------------------------------------*/

-(void)beginEvolution{
    
    [self setValue:[NSNumber numberWithBool:YES] forKey:@"inWork"];
    
    //Генерируем необходимую популяцию ДНК;
    population = [[Population alloc] initWithCapacity: populationSize andDnaLength: dnaLength];
    [population setDnaLength: dnaLength];
     Cell * goal = [[Cell alloc] initFromString: goalDNA];
    [population setGoalCell: goal];
    [population setMutationRate: mutationRate];
    [population setGeneration: 0];
    
    //Пока никто не намет кнопку Pause, будем запускаем метод генерации поколения;
    while (inWork) {
        [self performGeneration];
    }
    
    
}


// Метод генерирует одно поколение
-(void)performGeneration {
    
    // Кривоватый такой инкремент, но, почему-то, если просто написать generator++, то привязка формы к переменной не работает.
    [self setValue:[NSNumber numberWithLong:generation+1] forKey:@"generation"];
    
    
    // Сортируем популяцию по близости к goalDNA;
    Cell * goal = [[Cell alloc] initFromString: goalDNA];
    [population sortByHammingDistanceFromGoalDNA: goal];
    
    [self setValue:[NSNumber numberWithLong: [[[population population] objectAtIndex: 0] hammingDistance: goal] ] forKey:@"minHammingDistance"];
    
    // Проверяем, если пора остановиться, то прекращаем эволюцию;

    BOOL flag = [population stepEvolutionForGoalDNA:goal withMutationRate: mutationRate];
    if ( flag )
    {
        [self setValue:[NSNumber numberWithBool:NO] forKey:@"inWork"];
        return;
    }
    
    
    
}

- (IBAction)startEvolution:(id)sender{
    
    [self setValue:[NSNumber numberWithBool:NO] forKey:@"firstStart"];
    // Запускаем эволюцию в отдельном потоке.
    [self performSelectorInBackground:@selector(beginEvolution) withObject:nil];
    
}

- (IBAction)pauseEvolution:(id)sender {
    [self setValue:[NSNumber numberWithBool:NO] forKey:@"inWork"]; // В нашем случае нужно просто засерить все кнопки;
}
// Читаем из файла с проверкой на формат текста внутри;
- (IBAction)loadGoalDNA:(id)sender {
    
    
    NSOpenPanel * zOpenPanel = [NSOpenPanel openPanel];
    NSArray * zAryOfExtensions = [NSArray arrayWithObject:@"txt"];
    [zOpenPanel setAllowedFileTypes:zAryOfExtensions];
    NSInteger zIntResult = [zOpenPanel runModal];
    if (zIntResult == NSFileHandlingPanelCancelButton) {
        NSLog(@"Error in file");
        return;
    }
    NSURL *zUrl = [zOpenPanel URL];
    
    
    NSString * zStr = [NSString stringWithContentsOfURL:zUrl
                                               encoding:NSUTF8StringEncoding
                                                  error:NULL];
    
    if (([zStr length] > 0) && ([Cell isValidDNAString: zStr])) {
        [self setValue:[NSNumber numberWithLong:[zStr length]] forKey:@"dnaLength"];
        [self setValue:zStr forKey:@"goalDNA"];
    }
}
@end
