//
//  Population.m
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//

#import "Population.h"

@implementation Population

-(id) initWithCapacity:(NSUInteger) capacity andDnaLength:(NSUInteger) dLength{
    if (self = [super init]) {
        _population = [NSMutableArray arrayWithCapacity:capacity];
        _dnaLength = dLength;
        _populationSize = capacity;
        for (int i = 0; i < capacity; i++) {
            Cell * newCell = [[Cell alloc] initWithCapacity: dLength];
            [_population addObject:newCell];
        }
    }
    return self;
}





-(BOOL) stepEvolutionForGoalDNA:(Cell *)goalDNA withMutationRate: (NSUInteger) mutRate{
    _dnaLength = [goalDNA dnaLength];
    _goalCell = [_goalCell initFromString:[goalDNA printable]];
    _mutationRate = mutRate;
    // Sorting;
    [self sortByHammingDistanceFromGoalDNA:goalDNA];
    //Checking;
    if (0 == [[_population objectAtIndex:0] hammingDistance: goalDNA]) {
        return YES;
    }
    
    //Crossing
    int newChoise = arc4random_uniform((int)[_population count]/2);
    int otherChoise = arc4random_uniform((int)[_population count]/2);
    
    for (int i = 0; i < [_population count]/2; i++) {
        newChoise = arc4random_uniform((int)[_population count]/2);
        otherChoise = arc4random_uniform((int)[_population count]/2);
        [_population replaceObjectAtIndex:i + [_population count]/2
                               withObject:[[_population objectAtIndex:newChoise]
                                           crossCell:[_population objectAtIndex:otherChoise]
                                           ]];
    }
    
    //Mutating
    for (int i = 0; i < [_population count]; i++) {
        [[_population objectAtIndex: i] mutateDNA: mutRate];
    }
    _generation += 1;
    
    return NO;
}
/*--------------------------------------------------------------------------------------------------------*/
// Пока не за енкодил;
/*
-(NSDictionary *)toDict{
    NSMutableDictionary *result = [NSMutableDictionary dictionary];
    
    [result setObject:[NSString stringWithFormat:@"%04ld",++(_generation)] forKey:@"Generation"];
    
    Cell * first = [_population objectAtIndex:0];
    NSUInteger distance = [_goalCell hammingDistance: first];
    NSString *stringedDistance = [NSString stringWithFormat:@"%04ld", distance];
    [result setObject:stringedDistance forKey:@"Distance"];
    
    [result setObject:[first printable] forKey:@"BestMatch"];
    return result;
}
*/
/*--------------------------------------------------------------------------------------------------------*/
// Sort by Comparator Descending
-(void) sortByHammingDistanceFromGoalDNA: (Cell *) goalDNA {
    [_population sortUsingComparator:^NSComparisonResult(id a, id b) {
        NSUInteger value1 = [(Cell *)a hammingDistance: goalDNA];
        NSUInteger value2 = [(Cell *)b hammingDistance: goalDNA];
        
        
        if (value1 > value2)
        {
            return (NSComparisonResult)NSOrderedDescending;
        }
        
        if (value1 < value2)
        {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    }];
    // bestMatch initiation;
    _goalCell = goalDNA;
    _bestMatch = (int) 100 * (1 - ([[_population objectAtIndex: 0] hammingDistance: goalDNA]) / [goalDNA dnaLength]);
}

@end
