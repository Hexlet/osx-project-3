//
//  Cell.h
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ScreenSaver/ScreenSaver.h>

@interface Cell : NSObject {
    
    NSMutableArray* DNA;
    
}

@property NSUInteger dnaLength;

-(id) initWithCapacity: (NSUInteger) dnaLength;

-(NSUInteger) hammingDistance:(Cell *) anotherDNA;

-(void) mutateDNA:(NSUInteger) percent;

-(NSString *) printable;

-(Cell *) crossCell: (Cell *) cell;

- (id) initFromString: (NSString*)sourceString;

+(BOOL)isValidDNAString:(NSString *)string;


@end