//
//  Document.h
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class Population;

@interface Document : NSDocument{
    NSUInteger populationSize;
    NSUInteger dnaLength;
    NSUInteger mutationRate;
    NSUInteger bestMatch;
    NSUInteger generation;
    NSUInteger minHammingDistance;
    
    NSString *goalDNA;
    
    
    //Переменная для активации/деактивации элементов формы
    //YES, когда идут расчеты (элементы деактивированны), NO, когда расчеты не идут (элементы активированы)
    BOOL inWork;
    
    //Переменная для отслеживания первого запуска
    //Мы же можем цикл на паузу поставить.
    BOOL firstStart;
    
    
    Population *population;
}

@property (weak) IBOutlet NSTextField *fieldGoalDNA;
@property (weak) IBOutlet NSTextField *fieldPopulationSize;
@property (weak) IBOutlet NSTextField *fieldDnaLength;
@property (weak) IBOutlet NSTextField *fieldMutationRate;

@property (weak) IBOutlet NSSlider *sliderPopulationSize;
@property (weak) IBOutlet NSSlider *sliderDnaLength;
@property (weak) IBOutlet NSSlider *sliderMutationRate;

@property (weak) IBOutlet NSTextField *labelGeneration;
@property (weak) IBOutlet NSTextField *labelBestMatch;

@property (weak) IBOutlet NSLevelIndicator *progressBar;

@property (weak) IBOutlet NSButton *buttonStartEvolution;
@property (weak) IBOutlet NSButton *buttonPauseEvolution;
@property (weak) IBOutlet NSButton *buttonLoadGoalDNA;

- (IBAction)startEvolution:(id)sender;
- (IBAction)pauseEvolution:(id)sender;
- (IBAction)loadGoalDNA:(id)sender;


@end
