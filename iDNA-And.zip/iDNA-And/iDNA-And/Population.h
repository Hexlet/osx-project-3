//
//  Population.h
//  iDNA-And
//
//  Created by Lion on 03/01/2013.
//  Copyright (c) 2013 Lion User. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cell.h"

@interface Population : NSObject

@property NSUInteger mutationRate, populationSize, dnaLength;
@property NSUInteger bestMatch;
@property NSUInteger generation;

@property Cell * goalCell;
@property NSMutableArray *population;

-(id) initWithCapacity:(NSUInteger) capacity andDnaLength:(NSUInteger) dLength;

-(BOOL) stepEvolutionForGoalDNA:(Cell *) goalDNA withMutationRate: (NSUInteger) mutRate;

-(void) sortByHammingDistanceFromGoalDNA: (Cell *) goalDNA;

@end